﻿namespace BankAPIV7.Services
{
    public class LdapConfig
    {
        public string? Path { get; set; }
        public string? UserDomainName { get; set; }
    }
}
